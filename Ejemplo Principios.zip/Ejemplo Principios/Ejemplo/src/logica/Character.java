package logica;

/**
 * Character's abstract class.
 * <p>
 * The class predefines the features and actions of a character.
 * @author Julian
 */
public abstract class Character {

    /**
     * 
     * Character's name.
     * 
     * @see Character
     * @since version 1.00
     */
    protected String name;

    /**
     * 
     * Character's race.
     * 
     * @see Character
     * @since version 1.00
     */
    protected String race;

    /**
     * 
     * Character's weapon.
     * 
     * @see Character
     * @since version 1.00
     */
    protected String weapon;

    /**
     * 
     * Weapon's image path.
     * 
     * @see Character
     * @since version 1.00
     */
    protected String weaponSample;

    /**
     * 
     * Character's gender
     * 
     * @see Character
     * @since version 1.00 
     */
    protected String gender;

    /**
     * 
     * Character's health.
     * 
     * @see Character
     * @since version 1.00
     */
    protected Double health;

    /**
     * 
     * Character's velocity.
     * 
     * @see Character
     * @since version 1.00
     */
    protected Double velocity;

    /**
     * 
     * Character's attack.
     * 
     * @see Character
     * @since version 1.00 
     */
    protected Double attack;
    
    /**
     * 
     * Sets an image path for the selected weapon.
     * 
     * @see Character
     * @since version 1.00
     * @param weapon 
     */
    public void setWeaponSample(String weapon){
    }
    
    /**
     * 
     * Sets health value for character.
     * 
     * @see Character
     * @since version 1.00
     */
    public void setHealth(){
    }
        
    /**
     * 
     * Sets velocity value for character.
     * 
     * @see Character
     * @since version 1.00
     */
    public void setVelocity(){
    }
    
    /**
     * 
     * Sets attack value for character.
     * 
     * @see Character
     * @since version 1.00
     */
    public void setAttack(){
    }
    
    /**
     *
     * Gets the character's name.
     * 
     * @return name
     * @see Character
     * @since version 1.00
     */
    public String getName(){
        return name;
    }
    
    /**
     *
     * Gets the character's race.
     * 
     * @return race
     * @see Character
     * @since version 1.00
     */
    public String getRace(){
        return race;
    }
    
    /**
     *
     * Gets the character's weapon.
     * 
     * @return weapon
     * @see Character
     * @since version 1.00
     */
    public String getWeapon(){
        return weapon;
    }
    
    /**
     *
     * Gets the weapon's image path.
     * 
     * @return weapon's image path
     * @see Character
     * @since version 1.00
     */
    public String getWeaponSample(){
        return weaponSample;
    }
    
     /**
     *
     * Gets the character's gender.
     * 
     * @return gender
     * @see Character
     * @since version 1.00
     */
    public String getGender(){
        return gender;
    }
    
     /**
     *
     * Gets the character's health.
     * 
     * @return health
     * @see Character
     * @since version 1.00
     */
    public double getHealth(){
        return health;
    }
    
     /**
     *
     * Gets the character's velocity.
     * 
     * @return velocity
     * @see Character
     * @since version 1.00
     */
    public double getVelocity(){
        return velocity;
    }
    
     /**
     *
     * Gets the character's attack.
     * 
     * @return attack
     * @see Character
     * @since version 1.00
     */
    public double getAttack(){
        return attack;
    }
}
