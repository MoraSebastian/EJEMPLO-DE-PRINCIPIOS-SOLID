package logica;

/**
 *
 * Class which defines features and actions of an Uruk-Hai character.
 * 
 * @author Julian
 */
public class UrukHai extends Character{
    
    /**
     *
     * constructor which assings specific features to the Uruk-Hai character.
     * 
     * @param name
     * @param race
     * @param gender
     * @param weapon
     * @see Balrog
     * @since version 1.00
     */
    public UrukHai(String name, String race, String gender, String weapon){  
        this.name = name;
        this.race = race;
        this.gender = gender;
        this.weapon = weapon;
        setHealth();
        setVelocity();
        setAttack();
    }
    
    
    
    @Override
    public void setHealth(){
        if (gender.equals("male")){
            health = 115.0;
        }
        if (gender.equals("female")){
            health = 105.0;
        }
    }
    
    @Override
     public void setVelocity(){
        if (gender.equals("male") && weapon.equals("sword")){
            velocity = 2.5;
        }
        if (gender.equals("male") && weapon.equals("bow")){
            velocity = 3.0;
        }
        if (gender.equals("male") && weapon.equals("witchery")){
            velocity = 2.8;
        }
        if (gender.equals("female") && weapon.equals("sword")){
            velocity = 3.5;
        }
        if (gender.equals("female") && weapon.equals("bow")){
            velocity = 4.5;
        }
        if (gender.equals("female") && weapon.equals("witchery")){
            velocity = 2.8;
        }
    }
    
    @Override
    public void setAttack(){
        if (gender.equals("male") && weapon.equals("sword")){
            attack = 15.0;
        }
        if (gender.equals("male") && weapon.equals("bow")){
            attack = 11.0;
        }
        if (gender.equals("male") && weapon.equals("witchery")){
            attack = 13.0;
        }
        if (gender.equals("female") && weapon.equals("sword")){
            attack = 10.0;
        }
        if (gender.equals("female") && weapon.equals("bow")){
            attack = 7.5;
        }
        if (gender.equals("female") && weapon.equals("witchery")){
            attack = 9.0;
        }
    }
}
