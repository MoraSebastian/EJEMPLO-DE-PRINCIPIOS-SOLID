package logica;

/**
 *
 * Class which defines features and actions of a Balrog character.
 * 
 * @author Julian
 */
public class Balrog extends Character{
    
    /**
     *
     * constructor which assings specific features to the Balrog character.
     * 
     * @param name
     * @param race
     * @param gender
     * @param weapon
     * @see Balrog
     * @since version 1.00
     */
    public Balrog(String name, String race, String gender, String weapon){  
        this.name = name;
        this.race = race;
        this.gender = gender;
        this.weapon = weapon;
        setHealth();
        setVelocity();
        setAttack();
    }
    
    
    @Override
    public void setHealth(){
        if (gender.equals("male")){
            health = 320.0;
        }
        if (gender.equals("female")){
            health = 300.0;
        }
    }
    
    @Override
     public void setVelocity(){
        if (gender.equals("male") && weapon.equals("sword")){
            velocity = 3.5;
        }
        if (gender.equals("male") && weapon.equals("bow")){
            velocity = 2.0;
        }
        if (gender.equals("male") && weapon.equals("witchery")){
            velocity = 1.8;
        }
        if (gender.equals("female") && weapon.equals("sword")){
            velocity = 4.5;
        }
        if (gender.equals("female") && weapon.equals("bow")){
            velocity = 4.0;
        }
        if (gender.equals("female") && weapon.equals("witchery")){
            velocity = 3.8;
        }
    }
    
    @Override
    public void setAttack(){
        if (gender.equals("male") && weapon.equals("sword")){
            attack = 15.0;
        }
        if (gender.equals("male") && weapon.equals("bow")){
            attack = 11.0;
        }
        if (gender.equals("male") && weapon.equals("witchery")){
            attack = 13.0;
        }
        if (gender.equals("female") && weapon.equals("sword")){
            attack = 11.0;
        }
        if (gender.equals("female") && weapon.equals("bow")){
            attack = 8.5;
        }
        if (gender.equals("female") && weapon.equals("witchery")){
            attack = 9.0;
        }
    }
}

