package logica;

/**
 *
 * Class which creates characters.
 * 
 * @author Julian
 */
public class Creator {
    
    /**
     *
     * Create's character with the specific inputted features.
     * 
     * @see Creator
     * @since version 1.00
     * @param realNickname
     * @param race
     * @param gender
     * @param weapon
     * @return character
     */
    public static Character create (String realNickname, String race, String gender, String weapon){
        switch (race) {
            case "1":
                race = "Maiar";
                return new Maiar(realNickname, race, gender, weapon);
            case "2":
                race = "Balrog";
                return new Balrog(realNickname, race, gender, weapon);
            case "3":
                race = "Uruk-Hai";
                return new UrukHai(realNickname, race, gender, weapon);
            case "4":
                race = "Orc";
                return new Orc(realNickname, race, gender, weapon);
            default:
                return null;
        }
    }    
}
