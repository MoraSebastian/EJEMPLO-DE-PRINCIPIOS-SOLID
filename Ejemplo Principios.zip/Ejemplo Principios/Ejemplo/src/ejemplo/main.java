/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import logica.Creator;
import logica.Character;

/**
 *
 * @author Andrés Arias
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String raza = "";
        String nombre = "";
        String sexo = "";
        String arma = "";

        System.out.println("CREADOR DE CARACTERES");
        System.out.println();
        System.out.println("Seleccione el tipo de personaje:");
        System.out.println("1. Maiar");
        System.out.println("2. Barlog");
        System.out.println("3. Uruk-Hai");
        System.out.println("4. Orc");
        System.out.print("Opción: ");
        raza = in.readLine();
        System.out.println();
        System.out.print("Nombre: ");
        nombre = in.readLine();
        System.out.println();
        System.out.print("Sexo: A. Masculino B. Femenino  ");
        sexo = in.readLine();

        switch (sexo) {
            case "A":
                sexo = "male";
                break;
            case "B":
                sexo = "female";
                break;
        }

        System.out.println();
        System.out.println("Arma: ");
        System.out.println("A. Espada");
        System.out.println("B. Arco");
        System.out.println("C. Báculo");
        System.out.print("Opción: ");
        arma = in.readLine();

        switch (arma) {
            case "A":
                arma = "sword";
                break;
            case "B":
                arma = "bow";
                break;
            case "C":
                arma = "witchery";
                break;
        }

        //Creación del personaje
        Character character = Creator.create(nombre, raza, sexo, arma);

        System.out.println("¡PERSONAJE CREADO!");
        System.out.println();
        System.out.println("Descripción:");
        System.out.println();
        System.out.println("Nombre: " + character.getName());
        if (character.getGender().equals("male")) {
            System.out.println("Sexo: Masculino");
        } else {
            System.out.println("Sexo: Femenino");
        }

        System.out.print("Ataque: ");
        switch (character.getWeapon()) {
            case "sword":
                System.out.print("Espada");
                break;
            case "bow":
                System.out.print("Arco");
                break;
            case "witchery":
                System.out.print("Báculo");
                break;
        }
        System.out.println();
        System.out.println("Salud: " + character.getHealth());
        System.out.println("Velocidad: " + character.getVelocity());
        System.out.println("Ataque: " + character.getAttack());
    }

}
